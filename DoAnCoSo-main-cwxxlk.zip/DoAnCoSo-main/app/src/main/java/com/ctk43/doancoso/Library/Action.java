package com.ctk43.doancoso.Library;

public class Action {
    public static final int NONE = -1;
    public static final int ACTION_COMPLETE = 0;
    public static final int ACTION_PAUSE = 1;
    public static final int ACTION_RESUME = 2;
    public static final int ACTION_CANCEL = 3;
    public static final int ACTION_START = 4;
}
