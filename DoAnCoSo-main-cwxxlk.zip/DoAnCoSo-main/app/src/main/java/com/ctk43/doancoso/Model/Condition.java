package com.ctk43.doancoso.Model;

public class Condition {

    public  int IDNeed;
    public  int IDJobD;

    public Condition(int IDNeed, int IDJobD) {
        this.IDNeed = IDNeed;
        this.IDJobD = IDJobD;
    }
}
