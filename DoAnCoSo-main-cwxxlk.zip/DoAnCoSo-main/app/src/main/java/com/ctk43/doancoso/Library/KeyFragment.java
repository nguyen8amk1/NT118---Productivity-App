package com.ctk43.doancoso.Library;

public class KeyFragment {
    public static final int MANAGE_JOBS_PREVIOUS =0;
    public static final int MANAGE_JOBS_CURR =1;
    public static final int MANAGE_JOBS_NEXT =2;

    public static final int MANAGE_JOBS =0;
    public static final int MONTH =1;
    public static final int SETTING =2;
    public static final int PROFILE =3;
}
